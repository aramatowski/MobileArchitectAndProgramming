package com.guide.eventtrackingapp;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.guide.eventtrackingapp.Event;
import com.guide.eventtrackingapp.EventService;

import androidx.appcompat.app.AppCompatActivity;


public class EventActivity extends SecondActivity {
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;

    private EditText EventName;
    private EditText EventDate;
    private TextView Heading;
    private TextView EventList;
    private Button AddEvent;
    private Button DeleteEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_database);

        Heading = (TextView)findViewById(R.id.textView11);
        EventList = (TextView)findViewById(R.id.textView12);
        AddEvent = (Button)findViewById(R.id.button);
        DeleteEvent = (Button)findViewById(R.id.button4);
        EventName = (EditText)findViewById(R.id.editTextTextEventName);
        EventDate = (EditText)findViewById(R.id.editTextDate);

        AddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db = openHelper.getWritableDatabase();
                String Name = EventName.getText().toString();
                String Date = EventDate.getText().toString();
            }
        });

        DeleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    private void add(String eventName, String date, String description) {

    }
}
