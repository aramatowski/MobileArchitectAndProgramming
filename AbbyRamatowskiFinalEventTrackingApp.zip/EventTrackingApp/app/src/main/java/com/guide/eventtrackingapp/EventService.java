package com.guide.eventtrackingapp;

import com.guide.eventtrackingapp.Event;

import java.util.HashMap;
import java.util.Map;

public class EventService {
    private static EventService reference = new EventService();
    private final Map<String, Event> events;

    EventService() {
        this.events = new HashMap<String, Event>();
    }

    public static EventService getService() {
        return reference;
    }

    public boolean addEvent(Event event) {
        boolean isSuccess = false;

        if (!events.containsKey(event.getEventName())) {
            events.put(event.getEventName(), event);
            isSuccess = true;
        }
        return isSuccess;
    }

    public boolean deleteEvent(String eventName) {
        return events.remove(eventName) != null;
    }

    public boolean Event getEvents(String eventType) {
        return events.get(eventType);
    }
}
