package com.guide.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity{

    Button SocialEvents;
    Button Entertainment;
    Button FamilyEvents;
    Button SchoolEvents;
    Button WorkEvents;
    Button SportingEvents;
    Button Errands;
    Button Appointments;
    Button Deadlines;
    Button Other;
    private Button NotificationSettings;
    private Boolean buttonSelected = false;
    String headingType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        SocialEvents = (Button)findViewById(R.id.button14);
        Entertainment = (Button)findViewById(R.id.button15);
        FamilyEvents = (Button)findViewById(R.id.button16);
        SchoolEvents = (Button)findViewById(R.id.button17);
        WorkEvents = (Button)findViewById(R.id.button18);
        SportingEvents = (Button)findViewById(R.id.button19);
        Errands = (Button)findViewById(R.id.button20);
        Appointments = (Button)findViewById(R.id.button21);
        Deadlines = (Button)findViewById(R.id.button22);
        Other = (Button)findViewById(R.id.button23);
        NotificationSettings = (Button)findViewById(R.id.button24);

        if (buttonSelected == false) {
            SocialEvents.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Social";
                }
            });
            Entertainment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Entertainment";
                }
            });
            FamilyEvents.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Family";
                }
            });
            SchoolEvents.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "School";
                }
            });
            WorkEvents.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Work";
                }
            });
            SportingEvents.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Sport";
                }
            });
            Errands.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Errand";
                }
            });
            Appointments.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Appointment";
                }
            });
            Deadlines.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "deadline";
                }
            });
            Other.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    buttonSelected = true;
                    headingType = "Other";
                }
            });
            NotificationSettings.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent1 = new Intent(SecondActivity.this, NotificationActivity.class);
                    startActivity(intent1);
                }
            });
        }
        else {
            Intent intent = new Intent(SecondActivity.this, EventActivity.class);
            startActivity(intent);
        }
    }
}
