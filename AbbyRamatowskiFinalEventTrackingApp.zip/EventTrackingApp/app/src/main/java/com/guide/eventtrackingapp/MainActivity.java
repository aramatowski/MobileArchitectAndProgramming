package com.guide.eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;


    private EditText EmailAddress;
    private EditText Password;
    private TextView Info;
    private TextView CreateSuccess;
    private Button Login;
    private Button CreateAccount;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        openHelper = new DatabaseHelper(this);
        EmailAddress = (EditText)findViewById(R.id.editTextTextEmailAddress);
        Password = (EditText)findViewById(R.id.editTextTextPassword);
        Info = (TextView)findViewById(R.id.textView6);
        CreateSuccess = (TextView)findViewById(R.id.textView7);
        Login = (Button)findViewById(R.id.button2);
        CreateAccount = (Button)findViewById(R.id.button3);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(EmailAddress.getText().toString(), Password.getText().toString());
            }
        });

        CreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db = openHelper.getWritableDatabase();
                String Email = EmailAddress.getText().toString();
                String Password = Password.getText().toString();
                insertData(Email, Password);
            }
        });
    }

    private void validate(String userEmail, String userPassword) {
        if ((userEmail == "Admin") && (userPassword == "1234")) {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        }
        else {
            counter--;

            Info.setText("Login failed. Number of attempts remaining: " + String.valueOf(counter));

            if (counter == 0) {
                Login.setEnabled(false);
            }

        }
    }

    public void insertData(String Email, String Password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_2, Email);
        contentValues.put(DatabaseHelper.COL_3, Password);
        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
        CreateSuccess.setText("Account Created Successfully");
    }
}