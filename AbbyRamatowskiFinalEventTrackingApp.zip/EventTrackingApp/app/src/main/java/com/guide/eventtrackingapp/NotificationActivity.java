package com.guide.eventtrackingapp;

import android.os.Bundle;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class NotificationActivity extends AppCompatActivity {
    CheckBox checkBoxNotification;

    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        checkBoxNotification = (CheckBox)findViewById(R.id.checkBox);
    }
}
