package com.guide.eventtrackingapp;

import com.guide.eventtrackingapp.EventActivity;

public class Event {
    private String eventName;
    private String eventDate;
    private String eventType;

    public Event(String eventName, String eventDate, String eventType) {
        boolean isValid = validateInput(eventName);
        if (isValid) {
            this.eventName = eventName;
        }
        isValid = isValid && setEventName(eventName);
        isValid = isValid && setEventDate(eventDate);
        isValid = isValid && setEventType(eventType);

        if (!isValid) {
            throw new IllegalArgumentException("Invalid input");
        }
    }

    public boolean validateInput(String item) {
        return (item != null);
    }

    public boolean setEventName(String eventName) {
        boolean isValid = validateInput(eventName);
        if (isValid) {
            this.eventName = eventName;
        }
        return isValid;
    }

    public boolean setEventDate(String eventDate) {
        boolean isValid = validateInput(eventDate);
        if (isValid) {
            this.eventDate = eventDate;
        }
        return isValid;
    }

    public boolean setEventType(String eventType) {
        boolean isValid = validateInput(eventType);
        if (isValid) {
            this.eventType = eventType;
        }
        return isValid;
    }

    public String getEventName {
        return eventName;
    }

    public String getEventDate {
        return eventDate;
    }

    public String getEventType {
        return eventType;
    }
}
